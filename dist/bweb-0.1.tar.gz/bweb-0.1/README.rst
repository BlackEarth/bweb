bweb
================
Black Earth’s web interface library

	$ pip install bweb



